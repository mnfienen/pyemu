start_iteration 1  1  svd_base_par
termination_info_1 10 0 3 0 3
termination_info_2 0 3 0.01 0.01
termination_info_3 
parameter_file_save_started freyberg_reg.parb
parameter_file_save_finished freyberg_reg.parb
jacobian_model_runs_built
